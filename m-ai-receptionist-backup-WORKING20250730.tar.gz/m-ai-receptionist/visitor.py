from dataclasses import dataclass

@dataclass
class Visitor:
    name: str
    contact_info: str